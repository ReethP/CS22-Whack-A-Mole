package Game;
import java.util.Random;

//import Ex09.Bullet;
import javafx.scene.image.Image;
// import javafx.event.EventHandler;
// import javafx.scene.input.MouseEvent;
//import java.util.ArrayList;

public class Hole extends Sprite{
	private Mole mole;
	private boolean hasMole;
	//	private int timer;
	
	private final static int HOLE_WIDTH = 50;
	private final static int HOLE_LENGTH = 25;
	public final static Image HOLE_IMAGE = new Image("images/hole1.png",Hole.HOLE_WIDTH,Hole.HOLE_LENGTH,false,false);

	public Hole(int xcor, int ycor){
		super(xcor,ycor);
		Mole mole = new Mole(this,xcor,ycor);
		this.mole = mole;
		this.hasMole = false;
		this.loadImage(HOLE_IMAGE);
	}

	protected void tryUnhideMole(){
		Random r = new Random();
		int create = r.nextInt(101);
		if(create<30){
			this.mole.unhide();
			this.hasMole = true;
			int duration = r.nextInt(3)+3;
			this.mole.setTime(duration);
			Thread moleth = new Thread(this.mole);
			moleth.start();
		}
	}
	
	protected boolean checkMole() {
		return this.hasMole;
	}
	
	protected Mole getMole() {return this.mole;}
	
	

	protected void hideMole(){
		this.hasMole = false;
	}

	protected boolean hasMole(){
		return this.hasMole;
	}
}