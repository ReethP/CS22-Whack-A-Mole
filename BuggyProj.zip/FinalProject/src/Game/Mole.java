package Game;

//import java.util.Random;
//import javafx.scene.input.MouseEvent;
//import javafx.event.EventHandler;
import javafx.scene.image.Image;

public class Mole extends Sprite implements Runnable{
//	private float area;
	private boolean hidden;
	private int time;
	private Hole hole;
	private final static int MOLE_WIDTH = 50;
	public final static Image MOLE_IMAGE = new Image("images/mole1.png",Mole.MOLE_WIDTH,Mole.MOLE_WIDTH,false,false);
//	private int xcor;
//	private int ycor;
//	private int length;
//	private int width;

	public Mole(Hole hole,int xcor, int ycor){
		super(xcor,ycor);
		this.hidden = true;
		this.time = 0;
		this.hole = hole;
		this.loadImage(MOLE_IMAGE);
	}

	protected void trytohit(){
		if(!hidden){this.hidden = false;}
	}
	protected void unhide(){this.hidden = false;}
	protected void setTime(int time){this.time = time;}
	protected void hide(){}
	protected void adjustSpeed(){}
	protected void getHit(){}
	protected void addScore(){}
	protected boolean getHiddenStatus(){return this.hidden;}

// 	private void mouseClicked(MouseEvent e){
// //		public void handle(MouseEvent e){
// //            	// KeyCode code = e.getCode();
// //             //    moveMyShip(code);
// //		}
// 	}

	public void run(){
		while(this.time>0){
			this.time = this.time-1;
			System.out.println(time);
			try{Thread.sleep(1000);}catch (InterruptedException e){}
		}
		this.hidden = true;
		this.hole.hideMole();
	}

}