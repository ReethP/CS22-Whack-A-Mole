package Game;
//import Game.*;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
//import javafx.scene.layout.Background;
//import javafx.scene.layout.BackgroundImage;
//import javafx.scene.layout.BackgroundPosition;
//import javafx.scene.layout.BackgroundRepeat;
//import javafx.scene.layout.BackgroundSize;
//import javafx.scene.layout.Pane;
//import javafx.stage.Stage;
import java.util.ArrayList;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
//import javafx.event.EventHandler;
//import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import java.util.concurrent.TimeUnit;
//import javafx.scene.input.KeyCode;
//import javafx.scene.input.KeyEvent;
//import java.util.ArrayList;
//import java.util.Random;

//import Ex09.GameStage;

public class GameTest extends AnimationTimer{
	private GameStage stage;
	private Scene menuScene;
	private long start;
//	private Scene scene;
	
	private ImageView arrowBack;
	private ArrayList <Hole> holes;
	private GraphicsContext gc;
	public static final float WINDOW_HEIGHT = 460.8f;
	public static final int WINDOW_WIDTH = 768;
	private int spawned;

    public GameTest(GraphicsContext gc, Scene scene, GameStage gamestage){
    	this.stage = gamestage;
    	this.menuScene = scene;
    	this.start = System.nanoTime();
        this.gc = gc;
        this.spawned = 0;
    	// this.scene = new Scene(this.game, GameTest.WINDOW_WIDTH , GameTest.WINDOW_HEIGHT);
//        Image image = new Image("images/MALLETFINAL.png");  //pass in the image path
//        this.scene.setCursor(new ImageCursor(image));

        // Hole.handleMouseClickEvent();
        this.holes = new ArrayList<Hole>();
        makeHoles(this.holes);
        this.handleMouseEvent(this.holes);

        this.arrowBack = new ImageView();
        this.arrowBack.setImage(new Image("images/arrow.png"));
        this.arrowBack.setFitHeight(60);
        this.arrowBack.setFitWidth(60);
        this.arrowBack.setX(10);
        this.arrowBack.setY(10);
        this.arrowBack.setPickOnBounds(false); // allows click to not on transparent areas
        this.arrowBack.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked ArrowBack"); // change functionality
            this.stage.setScene(this.menuScene);
        });
    }
    
    public void handle(long currentNanoTime) {
        // int makemoles = 0;
        this.gc.clearRect(0, 0, GameTest.WINDOW_WIDTH,GameTest.WINDOW_HEIGHT);

        long currentSec = TimeUnit.NANOSECONDS.toSeconds(currentNanoTime);
        long startSec = TimeUnit.NANOSECONDS.toSeconds(this.start);
        if((currentSec - startSec)%2 == 0){
        if(this.spawned == 0) {
        System.out.println(currentSec);
        System.out.println(startSec);
        for(Hole hole:this.holes){
            if(!hole.hasMole()) hole.tryUnhideMole();
        }
        this.spawned = 1;}
        }else {this.spawned = 0;}

        for(Hole hole:this.holes){
            if(hole.checkMole()) hole.getMole().render(this.gc);
        }



        for(Hole hole:this.holes){
        	hole.render(this.gc);
        }
    }
    
    private void makeHoles(ArrayList<Hole> holes) {
    	Hole hole1,hole2,hole3,hole4,hole5,hole6;
    	hole1 = new Hole(150,150);
    	hole2 = new Hole(150,300);
    	hole3 = new Hole(500,300);
    	hole4 = new Hole(500,150);
    	hole5 = new Hole(325,150);
    	hole6 = new Hole(325,300);
    	holes.add(hole1);
    	 holes.add(hole2);
    	 holes.add(hole3);
    	 holes.add(hole4);
    	 holes.add(hole5);
    	 holes.add(hole6);
    }
    
    private void handleMouseEvent(ArrayList<Hole> holes){
		this.menuScene.setOnMouseClicked(new EventHandler<MouseEvent>(){
			public void handle(MouseEvent e){
				for(Hole hole:holes){
				if (hole.getBounds().contains(e.getX(),e.getY())){
					System.out.println("Hole clicked!");
				}					
				}
			}
		});
    }
    
//    public Scene getScene(){
//        return this.scene;
//    }
    

}