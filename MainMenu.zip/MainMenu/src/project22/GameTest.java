package project22;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.ImageCursor;

public class GameTest{
	private Stage stage;
	private Scene primaryScene;
	private Pane game;
	private Scene scene;
	private BackgroundImage background;
	private ImageView arrowBack;
	private ImageView lefthole;
	private ImageView lefthole2;
	private ImageView middlehole;
	private ImageView middlehole2;
	private ImageView righthole;
	private ImageView righthole2;
	private ImageView moletest;
//	private ImageView hitmole;
    public GameTest(Stage stage, Scene scene){
    	this.stage = stage;
    	this.primaryScene = scene;
    	this.game = new Pane();
    	this.scene = new Scene(this.game, 768, 460.8);
        Image image = new Image("file:src/MALLETFINAL.png");  //pass in the image path
        this.scene.setCursor(new ImageCursor(image));

        this.background= new BackgroundImage(new Image("file:src/background.jpg"), BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, new BackgroundSize(768, 460.8, true, true, true, true));
        this.game.setBackground(new Background(background));
        

        this.arrowBack = new ImageView();
        this.arrowBack.setImage(new Image("file:src/arrow.png"));
        this.arrowBack.setFitHeight(60);
        this.arrowBack.setFitWidth(60);
        this.arrowBack.setX(10);
        this.arrowBack.setY(10);
        this.arrowBack.setPickOnBounds(false); // allows click to not on transparent areas
        this.arrowBack.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked ArrowBack"); // change functionality
            this.stage.setScene(this.primaryScene);
        });

        this.moletest = new ImageView();
        this.moletest.setImage(new Image("file:src/mole.png"));
        this.moletest.setFitHeight(90);
        this.moletest.setFitWidth(90);
        this.moletest.setX(150);
        this.moletest.setY(150);
        this.moletest.setPickOnBounds(false); // allows click to not on transparent areas
        this.moletest.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked Mole"); // change functionality
        });
        
        this.lefthole = new ImageView();
        this.lefthole.setImage(new Image("file:src/hole3.png"));
        this.lefthole.setFitHeight(30);
        this.lefthole.setFitWidth(90);
        this.lefthole.setX(150);
        this.lefthole.setY(150);
        this.lefthole.setPickOnBounds(false); // allows click to not on transparent areas
        this.lefthole.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked Left Hole"); // change functionality
        });
        
        this.lefthole2 = new ImageView();
        this.lefthole2.setImage(new Image("file:src/hole3.png"));
        this.lefthole2.setFitHeight(30);
        this.lefthole2.setFitWidth(90);
        this.lefthole2.setX(150);
        this.lefthole2.setY(300);
        this.lefthole2.setPickOnBounds(false); // allows click to not on transparent areas
        this.lefthole2.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked Left Hole"); // change functionality
        });
        
        this.righthole = new ImageView();
        this.righthole.setImage(new Image("file:src/hole2.png"));
        this.righthole.setFitHeight(30);
        this.righthole.setFitWidth(90);
        this.righthole.setX(500);
        this.righthole.setY(300);
        this.righthole.setPickOnBounds(false); // allows click to not on transparent areas
        this.righthole.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked Right Hole"); // change functionality
        });
        
        this.righthole2 = new ImageView();
        this.righthole2.setImage(new Image("file:src/hole2.png"));
        this.righthole2.setFitHeight(30);
        this.righthole2.setFitWidth(90);
        this.righthole2.setX(500);
        this.righthole2.setY(150);
        this.righthole2.setPickOnBounds(false); // allows click to not on transparent areas
        this.righthole2.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked Right Hole"); // change functionality
        });
        
        this.middlehole = new ImageView();
        this.middlehole.setImage(new Image("file:src/hole1.png"));
        this.middlehole.setFitHeight(30);
        this.middlehole.setFitWidth(90);
        this.middlehole.setX(325);
        this.middlehole.setY(150);
        this.middlehole.setPickOnBounds(false); // allows click to not on transparent areas
        this.middlehole.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked Middle Hole"); // change functionality
        });
        
        this.middlehole2 = new ImageView();
        this.middlehole2.setImage(new Image("file:src/hole1.png"));
        this.middlehole2.setFitHeight(30);
        this.middlehole2.setFitWidth(90);
        this.middlehole2.setX(325);
        this.middlehole2.setY(300);
        this.middlehole2.setPickOnBounds(false); // allows click to not on transparent areas
        this.middlehole2.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked Middle Hole"); // change functionality
        });

        
        this.game.getChildren().add(this.arrowBack);
        this.game.getChildren().add(this.lefthole);
        this.game.getChildren().add(this.righthole);
        this.game.getChildren().add(this.lefthole2);
        this.game.getChildren().add(this.righthole2);
        this.game.getChildren().add(this.middlehole);
        this.game.getChildren().add(this.middlehole2);
        this.game.getChildren().add(this.moletest);

        
    }
    public Scene getScene(){
        return this.scene;
    }
    

}