package project22;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Menu {
	private Stage stage;
	private Pane root;
	private Scene scene;
	private BackgroundImage background;
	private ImageView play;
	private ImageView instructions;
	private ImageView about;
	
	public Menu(Stage primaryStage) {
		//Main Menu
		this.stage = primaryStage;
		this.root = new Pane();
		this.scene = new Scene(this.root, 768, 460.8);
		//set scene size
		this.background = new BackgroundImage(new Image("file:src/WHACKMENU.jpg"), BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, new BackgroundSize(768, 460.8, true, true, true, true));
		//set background and background size

	}
	public void setMenu() {
		
		this.stage.setTitle("Whack-A-Mole");
        this.root.setBackground(new Background(this.background));
        this.stage.getIcons().add(new Image("file:src/mole1.png"));
        //set background and title
        
        this.play = new ImageView();
        this.play.setImage(new Image("file:src/button1.png"));
        this.play.setFitHeight(45.6);
        this.play.setFitWidth(141.6);
        //fix height and width
        this.play.setX(300);
        this.play.setY(330);
        //set coordinates on scene
        this.play.setPickOnBounds(false); // allows click on transparent areas
        this.play.setOnMouseClicked((MouseEvent e) -> {
        	//go to gametest scene if object is clicked
            System.out.println("Clicked Play");
            GameTest game = new GameTest(this.stage, this.scene);
            this.stage.setScene(game.getScene());
        });
        //above creates the play button
        
        this.instructions = new ImageView();
        this.instructions.setImage(new Image("file:src/button2.png"));
        this.instructions.setFitHeight(39.3);
        this.instructions.setFitWidth(141.6);
        this.instructions.setX(300);
        this.instructions.setY(377);
        this.instructions.setPickOnBounds(false); // allows click on transparent areas
        this.instructions.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked Instructions");
            InstructionsScene instructions = new InstructionsScene(this.stage, this.scene);
            this.stage.setScene(instructions.getScene());     
        });
        //above creates the instructions button, similar to play button
        
        this.about = new ImageView();
        this.about.setImage(new Image("file:src/button3.png"));
        this.about.setFitHeight(60);
        this.about.setFitWidth(60);
        this.about.setX(700);
        this.about.setY(400);
        this.about.setPickOnBounds(false); // allows to not click on transparent areas
        this.about.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Clicked About"); // change functionality
            AboutScene about = new AboutScene(this.stage, this.scene);
            this.stage.setScene(about.getScene());
        });
      //above creates the about button, similar to play button
         
        this.root.getChildren().add(this.play);
        this.root.getChildren().add(this.instructions);
        this.root.getChildren().add(this.about);
        //add buttons to scene
        this.stage.setResizable(false);
        //not allow to be resized
        this.stage.setScene(this.scene);
        this.stage.show();
        //show
	}
}
